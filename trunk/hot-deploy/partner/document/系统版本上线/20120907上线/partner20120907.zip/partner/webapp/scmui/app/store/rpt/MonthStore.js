Ext.define('SCM.store.rpt.MonthStore', {
			extend : 'Ext.data.Store',
			model : 'SCM.model.rpt.MonthModel',
			alias : 'MonthStore',
			autoLoad : false,
			autoSync : false
		});