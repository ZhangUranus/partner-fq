Ext.define('SCM.store.rpt.RptTestStore', {
			extend : 'Ext.data.Store',
			model : 'SCM.model.rpt.RptTestModel',
			alias : 'RptTestStore',
			autoLoad : false,
			autoSync : false
			
		});