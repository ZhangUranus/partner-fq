Ext.define('SCM.store.ProductInwarehouseConfirm.ProductInwarehouseConfirmDetailStore', {
			extend : 'Ext.data.Store',
			model : 'SCM.model.ProductInwarehouseConfirm.ProductInwarehouseConfirmDetailModel',
			alias : 'ProductInwarehouseConfirmDetailStore',
			autoLoad : false,
			autoSync : false
			
		});