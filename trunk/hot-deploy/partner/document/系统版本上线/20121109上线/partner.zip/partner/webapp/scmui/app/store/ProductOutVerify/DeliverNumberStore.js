Ext.define('SCM.store.ProductOutVerify.DeliverNumberStore', {
			extend : 'Ext.data.Store',
			model : 'SCM.model.ProductOutVerify.DeliverNumberModel',
			alias : 'DeliverNumberStore',
			autoLoad : false,
			autoSync : false
		});