Ext.define('SCM.store.WorkshopOtherDrawBill.WorkshopOtherDrawBillEditStore', {
			extend : 'Ext.data.Store',
			model : 'SCM.model.WorkshopOtherDrawBill.WorkshopOtherDrawBillEditModel',
			alias : 'WorkshopOtherDrawBillEditStore',
			autoLoad : false,
			autoSync : false
		});