Ext.define('SCM.store.ProductInwarehouseConfirm.ProductInwarehouseConfirmStore', {
			extend : 'Ext.data.Store',
			model : 'SCM.model.ProductInwarehouseConfirm.ProductInwarehouseConfirmModel',
			alias : 'ProductInwarehouseConfirmStore',
			autoLoad : false,
			autoSync : false
		});